package cat.gencat.crudBasic.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.jpa.JpaCallback;

import cat.gencat.crudBasic.dao.TbUsuariDAO;
import cat.gencat.crudBasic.model.TbUsuaris;
import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.ctti.canigo.arch.persistence.jpa.exception.PersistenceException;

//TODO 2 Modificar TbUsuaris per l'objecte de mapping que es vulgui realitzar el crud, i les refer�ncies a TbUsuaris i als seus atributs dins el m�tode findFiltered
public class TbUsuariDAOImpl extends JPAGenericDaoImpl<TbUsuaris, Integer>
		implements TbUsuariDAO {

	@SuppressWarnings("unchecked")
	public List<TbUsuaris> findFiltered(final String filter) {
		List<TbUsuaris> results = getJpaTemplate().executeFind(
				new JpaCallback<List<TbUsuaris>>() {
					public List<TbUsuaris> doInJpa(EntityManager em) throws PersistenceException {	
						Session session = (Session) em.getDelegate();
						Criteria crit = session.createCriteria(TbUsuaris.class);
						if (filter != null && !"".equals(filter)) {
							crit.add(Restrictions.or(Restrictions.or(Restrictions.or(
									Restrictions.like("nom", "%" + filter + "%"),
									Restrictions.like("cognoms", "%" + filter + "%")),
									Restrictions.like("email", "%" + filter + "%")),
									Restrictions.like("nif", "%" + filter + "%")));
						}
						return (List<TbUsuaris>) crit.list();
					}
				
				});
		return results;
	}
}
