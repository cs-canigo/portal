#!/bin/bash

function log() {
    moment=`date '+%d/%m/%Y %H:%M:%S'` 
    echo "[ $moment ] $1"
}

function obtenirFitxerAutors() {
     
    log "Obtenint autors..."

    autorsSVN=$(svn --username=$username --password=$password log --xml $svn/$acroantic/$codi_dialeg --no-auth-cache | grep '<author>' | sort -u | sed 's/[/]//g' | sed 's/<author>//g')
    
    log "Mostrar autorsSVN: $autorsSVN"
    
    for authors in $autorsSVN; do
        log "Tractant autor: $authors"
        usersmails=$(java -jar ldapUtilities-0.0.1-jar-with-dependencies.jar ldapConfig.txt cercarUsuari $authors 2>&1 | grep -Eio '[a-z0-9._-]+@[a-z0-9.-]+[a-z]{2,4}')
        nomdelusuari=$(java -jar ldapUtilities-0.0.1-jar-with-dependencies.jar ldapConfig.txt cercarUsuari $authors 2>&1 | grep -oP '(?<=nom=).+?(?=homeDirectory)')
        cognomusuari=$(java -jar ldapUtilities-0.0.1-jar-with-dependencies.jar ldapConfig.txt cercarUsuari $authors 2>&1  | grep -oP '(?<=sn=).+?(?=uidNumber)')
        log "Mail de ${authors}: $usersmails"
        #si l'usuari no té assignat cap mail i o nom/cognom se'l hi assignarà un de generic per a poder crear correctametn el fitxer author.txt, passarà el mateix si són l'usuari root, gestioSIC, provesSIC o aqduser.
        if [ -z $usersmails ] && [ -z $nomdelusuari ]; then
            echo "$authors = $authors $authors <$authors@nomailgencat.cat>" >> author.txt
        elif [ -z $usersmails ]; then
            case $authors in
                gestioSIC)
                    echo "gestioSIC = GestioSIC Usuari Generic  <nouser@nomailgencat.cat>">> author.txt
                    ;;
                provesSIC)
                    echo "provesSIC = ProvesSIC Usuari Generic  <nouser@nomailgencat.cat>">> author.txt
                    ;;
                *)
                    echo "$authors = $nomdelusuari$cognomusuari <$authors@nomailgencat.cat>" >> author.txt
                    ;;
            esac
        else
            echo "$authors = $nomdelusuari$cognomusuari <$usersmails>" >> author.txt
        fi
    done
}


###############################################################################
# Programa principal
###############################################################################

log "Inici procés obtenir autors"

export acroantic=$1
export codi_dialeg=$2
export username=$3
export password=$4
export ldap='10.48.33.19'
export svn='http://svn.intranet.gencat.cat'


# Eliminar fitxer authors.txt si existeix
rm -f author.txt
# Entrar codi_dialeg


obtenirFitxerAutors $acroantic $codi_dialeg
  

