CREATE USER formacio
  IDENTIFIED BY canigo
  DEFAULT TABLESPACE users;
  
GRANT ALL privileges to formacio;