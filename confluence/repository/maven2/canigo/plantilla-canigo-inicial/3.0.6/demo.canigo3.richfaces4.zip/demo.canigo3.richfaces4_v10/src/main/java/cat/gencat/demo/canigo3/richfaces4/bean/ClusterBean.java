package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbCluster;
import cat.gencat.demo.canigo3.richfaces4.service.ClusterService;


@Controller("clusterBean")
@Scope("singleton")
@Lazy
public class ClusterBean {

	// Creaci� del bean del crud que s'estigui realitzant
	private TbCluster cluster = new TbCluster();
	private String nomCluster;
	
	public TbCluster getCluster() {
		return cluster;
	}

	public void setCluster(TbCluster cluster) {
		this.cluster = cluster;
	}
	
	public String getNomCluster(String idCluster) {
		nomCluster = service.getClusterName(Integer.valueOf(idCluster));
		return nomCluster;
	}

	public void setNomCluster(String nomCluster) {
		this.nomCluster = nomCluster;
	}



	// Injecci� de depend�ncia del Service creat
	@Autowired
	private ClusterService service;
	
	public List<SelectItem> getClusters() {
		List<TbCluster> llistaCluster = service.getLlistaCluster();
		
		List<SelectItem> items = new ArrayList<SelectItem>();
		for(TbCluster cluster : llistaCluster){
			items.add(new SelectItem(cluster.getIdCluster(), cluster.getNomCluster()));
		}
		return items;
	}
}
