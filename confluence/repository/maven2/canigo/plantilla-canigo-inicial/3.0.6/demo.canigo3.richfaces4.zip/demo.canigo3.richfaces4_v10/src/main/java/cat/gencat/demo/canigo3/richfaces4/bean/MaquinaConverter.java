package cat.gencat.demo.canigo3.richfaces4.bean;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbCluster;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;

@Service("maquinaConverter")
@Lazy
public class MaquinaConverter implements Converter{

	//@PersistenceContext
	//private EntityManager em;
	
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		try {
			if (value != null) {
				//System.out.println( "MaquinaConverter: converting string " + value + " to Maquina.");
				//return (TbMaquines) em.find( TbMaquines.class, Integer.valueOf(value));
				TbMaquines maquina = new TbMaquines();
				String[] components = value.split(":");
				maquina.setIdMaquina(new Integer(components[0]));
				maquina.setNomMaquina(components[1]);
				maquina.setSo(components[2]);
				maquina.setIp(components[3]);
				TbCluster cluster = new TbCluster();
				cluster.setIdCluster(new Integer(components[4]));
				cluster.setNomCluster(components[5]);
				maquina.setTbCluster(cluster);
				maquina.setIdDepartament(new Integer(components[6]));
				
				if (components[7].compareTo("null") == 0) {
					maquina.setIdInstrumentacio(new Integer(0));
				} else {
					maquina.setIdInstrumentacio(new Integer(components[7]));
				}

				maquina.setStatus(new Integer(components[8]));
				maquina.setDisponible(Boolean.valueOf(components[9]));
				return maquina;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		
		StringBuffer maquinaString = null;
		
		try {
			
			maquinaString = new StringBuffer();
			if (value != null) {
				TbMaquines maquina = (TbMaquines)value;
				maquinaString.append(maquina.getIdMaquina() + ":");
				maquinaString.append(maquina.getNomMaquina() + ":");
				maquinaString.append(maquina.getSo() + ":");
				maquinaString.append(maquina.getIp() + ":");
				maquinaString.append(maquina.getTbCluster().getIdCluster() + ":");
				maquinaString.append(maquina.getTbCluster().getNomCluster() + ":");
				maquinaString.append(maquina.getIdDepartament() + ":");
				maquinaString.append(maquina.getIdInstrumentacio() + ":");
				maquinaString.append(maquina.getStatus() + ":");
				maquinaString.append(maquina.getDisponible() + ":");
				return maquinaString.toString();
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
