package cat.gencat.dgac.domain;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.dgac.dao.UsuariDAO;
import cat.gencat.dgac.domain.beans.TUsuari;

//TODO 2 Modificar TUsuari per l'objecte de mapping que es vulgui realitzar el crud.
public class UsuariDAOImpl extends JPAGenericDaoImpl<TUsuari, Integer> implements UsuariDAO {

}
