-------------------------------------------------------------------------------------------------------------
--
-- Arxiu de inserci� de dades d'exemple a la bbdd hsql
-- ---------------------------------------------------
--
--	Insercions:
--		
--		Taula "USERS": s'inserta el nom d'usuari, la contrasenya i si est� habilitat o no. (1 = si, 0 = no).
--		Taula "GROUPS": s'inserta l'identificador i el nom del grup.
--		Taula "GROUP_AUTHORITIES": s'inserta l'identificador del grup i el rol.
--		Taula "GROUP_MEMBERS": s'inserta l'identificador, el nom d'usuari i el grup al que pertany.
--		Taula "AUTHORITIES": s'inserta el nom d'usuari i el rol al que pertany.
--
--
-------------------------------------------------------------------------------------------------------------
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina1', 'windows XP', '192.168.0.1',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina2', 'Fedora 11', '192.168.0.2',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina3', 'Ubuntu 10', '192.168.0.3',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina4', 'windows XP', '192.168.0.4',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina5', 'windows XP', '192.168.0.5',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina6', 'RedHat', '192.168.0.6',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina7', 'windows XP', '192.168.0.7',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina8', 'Ubuntu 10', '192.168.0.8',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina9', 'Ubuntu 10', '192.168.0.9',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina10', 'windows XP', '192.168.0.10',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina11', 'Fedora 11', '192.168.0.11',102,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina12', 'windows XP', '192.168.0.12',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina13', 'RedHat', '192.168.0.13',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina14', 'windows XP', '192.168.0.14',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina15', 'RedHat', '192.168.0.15',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina16', 'windows XP', '192.168.0.16',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina17', 'Fedora 11', '192.168.0.17',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina18', 'windows XP', '192.168.0.18',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina19', 'windows XP', '192.168.0.19',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina20', 'RedHat', '192.168.0.20',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina21', 'Fedora 11', '192.168.0.21',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina22', 'windows XP', '192.168.0.22',102,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina23', 'windows XP', '192.168.0.23',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina24', 'RedHat', '192.168.0.24',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina25', 'windows XP', '192.168.0.25',101,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina26', 'Ubuntu 10', '192.168.0.26',0,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina27', 'windows XP', '192.168.0.27',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina28', 'RedHat', '192.168.0.28',100,0,0,2,false);
insert into tb_maquines (nom_maquina, so, ip, id_cluster, id_departament, id_instrumentacio, status, disponible) values ('maquina29', 'windows XP', '192.168.0.29',102,0,0,2,false);

insert into tb_cluster (id_cluster, nom_cluster) values (0, 'No_Cluster');
insert into tb_cluster (id_cluster, nom_cluster) values (100, 'Cluster_I');
insert into tb_cluster (id_cluster, nom_cluster) values (101, 'Cluster_II');
insert into tb_cluster (id_cluster, nom_cluster) values (102, 'Cluster_III');

insert into tb_departament(id_departament, nom_departament) values (0, 'CTTI');
insert into tb_departament(id_departament, nom_departament) values (1, 'BSF');

insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Joan', 'Gracia', '93453784', 0, 'email1@gencat.cat', '345345345T', '1980-04-01', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Nuria', 'Martin', '95443784', 0, 'email2@gencat.cat', '75657465T', '1981-02-02', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Marta', 'Lopez', '93453724', 0, 'email3@gencat.cat', '12354654C', '1970-04-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Estela', 'Gin�s', '93153184', 0, 'email4@gencat.cat', '35462534F', '1990-05-25', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Cristian', 'Lopez', '94453704', 0, 'email5@gencat.cat', '16253643A', '1981-09-19', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Manel', 'Sanpedro', '93456794', 0, 'email6@gencat.cat', '45364530C', '1982-12-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Joel', 'Loras', '93423780', 0, 'email7@gencat.cat', '36453749Z', '1980-04-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Giorgina', 'Delgado', '94453484', 0, 'email8@gencat.cat', '435285764T', '1981-01-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Rafael', 'Lopez', '93773798', 0, 'email9@gencat.cat', '43528837A', '1980-01-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('David', 'Casado', '93563784', 0, 'email10@gencat.cat', '45528837S', '1981-01-11', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Xavier', 'Palau', '98453798', 0, 'email11@gencat.cat', '35528837R', '1980-03-24', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Jordi', 'Montserrat', '92353781', 0, 'email12@gencat.cat', '37728837M', '1982-04-15', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Jonathan', 'Palau', '93123781', 0, 'email13@gencat.cat', '37748837H', '1980-08-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Rocio', 'Casado', '95453781', 0, 'email14@gencat.cat', '345345345T', '1980-08-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Elena', 'Marzo', '99434784', 0, 'email51@gencat.cat', '36453749Z', '1980-06-12', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Julia', 'Rosado', '97459374', 0, 'email16@gencat.cat', '43528837A', '1982-09-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Ian', 'Tinto', '99053789', 0, 'email17@gencat.cat', '35528837R', '1980-10-16', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Joan', 'Puig', '91458280', 0, 'email18@gencat.cat', '345345345T', '1980-11-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Elena', 'Lopez', '98459289', 0, 'email19@gencat.cat', '45364530C', '1981-04-19', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Manel', 'Lopez', '96492784', 0, 'email123@gencat.cat', '36453749Z', '1981-11-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Jordi', 'Casado', '96457284', 0, 'email872@gencat.cat', '75657465T', '1980-04-03', 0);
insert into tb_usuaris (nom, cognoms, telefon, id_carrec, email, nif, data_naixement, id_departament) values ('Nuria', 'Perez', '96453824', 0, 'email231@gencat.cat', '36453749Z', '1980-02-03', 0);
commit;