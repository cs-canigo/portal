//package cat.gencat.demo.canigo3.richfaces4.bean;
//
//import java.io.InputStream;
//
//
//
//import org.apache.myfaces.custom.fileupload.UploadedFile;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.context.annotation.Scope;
//import org.springframework.stereotype.Controller;
//
//
//@Controller("pujadaArxiusBean")
//@Scope("singleton")
//@Lazy
//public class PujadaArxiusBean {
//	//INI: Dades necessaries pel FileUpload
//	private UploadedFile uploadedFile;
//	
//	public UploadedFile getUploadedFile() {
//		return uploadedFile;
//	}
//
//	public void setUploadedFile(UploadedFile uploadedFile) {
//		this.uploadedFile = uploadedFile;
//	}
//	//FIN: Dades necessaries pel FileUpload
//	
//	public void carregaFitxer() {
//		try {
//			if (null != this.uploadedFile) {
//				InputStream stream = this.uploadedFile.getInputStream();
//				System.out.println("[CercaUsuariBean][carregaFitxerAdjunt] Arxiu carregat OK!");
//			} else {
//				System.out.println("[CercaUsuariBean][carregaFitxerAdjunt] Arxiu carregat KO!");
//			}
//		} catch (Exception e) {
//			System.out.println("[CercaUsuariBean][carregaFitxerAdjunt][ERROR]");
//			e.printStackTrace();
//		}
//	}
//}
