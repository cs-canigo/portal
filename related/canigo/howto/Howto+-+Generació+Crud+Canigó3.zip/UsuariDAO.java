package cat.gencat.dgac.dao;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;
import cat.gencat.dgac.domain.beans.TUsuari;

//TODO 1 Cal inicialitzar el constructor de la interf�cie amb l'objecte sobre el que es vol realitzar el CRUD.
public interface UsuariDAO extends GenericDAO<TUsuari, Integer> {

}