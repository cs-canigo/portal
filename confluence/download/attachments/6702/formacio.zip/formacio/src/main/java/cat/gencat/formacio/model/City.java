package cat.gencat.formacio.model;

public class City {
	
	String cityName;
	String cityId;
	
	public String getCityName() {
		return this.cityName;
	}

	public City(String name){
		this.cityName=name;
		this.cityId="Id-"+name;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	
}
