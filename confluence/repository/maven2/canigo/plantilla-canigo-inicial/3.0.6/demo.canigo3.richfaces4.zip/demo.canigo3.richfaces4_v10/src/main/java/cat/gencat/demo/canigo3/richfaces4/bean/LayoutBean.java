package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.Iterator;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("layoutBean")
@Scope("request")
@Lazy
public class LayoutBean {
	private static final int SEVERITY_INFO = 0;
	private static final int SEVERITY_WARNING = 1;
	private static final int SEVERITY_ERROR = 2;
	
	private static final int NUM_MAX_PANELLS = 5;
	private static final String NOM_PARAMETRE_FORWARD = "accio";
	
//	private static final Log logger = LogFactory.getLog(LayoutBean.class);
	
	private Boolean[] panelGroups = new Boolean[NUM_MAX_PANELLS];
	
	
	public boolean getTeErrors() {
		return teMissatges(SEVERITY_ERROR);
	}
	public boolean getTeConfirmacions() {
		return teMissatges(SEVERITY_WARNING);
	}
	public boolean getTeInformacio() {
		return teMissatges(SEVERITY_INFO);
	}
	
	/**
	 * M�tode que indica si te missatges o no segons la severitat indicada.
	 * @param severity int 
	 * @return boolean
	 */
	private boolean teMissatges(int severity) {
		boolean teErrors = false; 
		FacesContext fc = FacesContext.getCurrentInstance(); 
		Iterator<FacesMessage> iterator = fc.getMessages();
		while(iterator.hasNext()) {
			FacesMessage message = iterator.next();
			if(message.getSeverity().getOrdinal() == severity) {
				teErrors = true;
				break;
			}
		}
		return teErrors;
	}
	
	/**
	 * M�tode que indica si hi ha missatges d'error o informatius, per a mostrar o no el text.
	 * @return boolean.
	 */
	public boolean getTeMissatges() {
		boolean teErrors = false; 
		FacesContext fc = FacesContext.getCurrentInstance(); 
		Iterator<FacesMessage> iterator = fc.getMessages();
		while(iterator.hasNext()) {
			teErrors = true;
			break;
		}
		return teErrors;
	}

	/**
	 * M�tode que permet realitzar redireccions, segons el par�metre enviat.
	 * @return String
	 */
	public String go() {
		FacesContext context = FacesContext.getCurrentInstance();
		String forward = (String) context.getExternalContext().getRequestParameterMap().get(NOM_PARAMETRE_FORWARD);
		return forward;
	}
	
	/**
	 * M�tode que retorna si existeis un usuari autenticat o no.
	 * @return boolean
	 */
	public boolean getAutenticat() {
		if(FacesContext.getCurrentInstance().getExternalContext().getRemoteUser() == null) {
			return false;
		}
		return true;
	}
	
	/**
	 * M�tode que retorna el nom de l'usuari autenticat.
	 * @return
	 */
	public String getLoggedUser() {
		return FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
	}
	
	/**
	 * M�tode que retorna una cadena amb el llistat de Rols de l'usuari
	 * @return String
	 */
	public String getRoleUser() {
		//Descomentar un cop s'afegeixi el servei de seguretat.
//		Object[] roles = SecurityContextHolder.getContext().getAuthentication().getAuthorities().toArray();
//		StringBuffer strRoles = new StringBuffer();
//		String separador = "";
//		for(Object role : roles) {
//			strRoles.append(separador).append(role);
//			separador = ", ";
//		}
//		return strRoles.toString();
		return "";
	}
	
	public Boolean[] getPanelGroups() {
		return panelGroups;
	}

	public void setPanelGroups(Boolean[] panelGroups) {
		this.panelGroups = panelGroups;
	}
}
