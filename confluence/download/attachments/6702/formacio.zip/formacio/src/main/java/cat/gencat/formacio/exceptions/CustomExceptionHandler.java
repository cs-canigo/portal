package cat.gencat.formacio.exceptions;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.FacesException;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.support.WebApplicationContextUtils;

import cat.gencat.ctti.canigo.arch.core.exceptions.WrappedCheckedException;
import cat.gencat.ctti.canigo.arch.core.i18n.I18nResourceBundleMessageSource;

public class CustomExceptionHandler extends ExceptionHandlerWrapper {

	private I18nResourceBundleMessageSource i18n;

	private static final Logger log = Logger
			.getLogger(CustomExceptionHandler.class.getCanonicalName());

	private ExceptionHandler wrapped;

	CustomExceptionHandler(ExceptionHandler exception) {
		this.wrapped = exception;
		this.i18n = WebApplicationContextUtils
				.getRequiredWebApplicationContext(
						(ServletContext) FacesContext.getCurrentInstance()
								.getExternalContext().getContext())
				.getBean(I18nResourceBundleMessageSource.class);
	}

	@Override
	public ExceptionHandler getWrapped() {
		return wrapped;
	}

	@Override
	public void handle() throws FacesException {

		final Iterator<ExceptionQueuedEvent> i = getUnhandledExceptionQueuedEvents()
				.iterator();
		while (i.hasNext()) {
			ExceptionQueuedEvent event = i.next();
			ExceptionQueuedEventContext context = (ExceptionQueuedEventContext) event
					.getSource();

			// get the exception from context
			Throwable t = context.getException();
			log.log(Level.SEVERE, "S'ha produ�t un error", t);

			WrappedCheckedException ex = getWrappedCheckedException(t);
			if (ex != null) {
				String errorMsg = i18n.getMessage(ex.getExceptionDetails()
						.getErrorCode());
				FacesContext.getCurrentInstance().addMessage(
						"errorsZone",
						new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMsg,
								errorMsg));
			} else {
				FacesContext.getCurrentInstance().addMessage(
						"errorsZone",
						new FacesMessage(FacesMessage.SEVERITY_ERROR, t
								.getMessage(), t.getMessage()));
			}

			// Veure GenericErrorUIBean.java i error.xhtml
			/*
			 * FacesContext.getCurrentInstance().getExternalContext().getSessionMap
			 * ().put("GLOBAL_RENDER_ERROR", ex);
			 */
		}

	}

	private WrappedCheckedException getWrappedCheckedException(Throwable th) {
		if (th instanceof WrappedCheckedException) {
			return (WrappedCheckedException) th;
		} else if (th == null || th.getCause() == null) {
			return null;
		} else {
			return getWrappedCheckedException(th.getCause());
		}
	}

}
