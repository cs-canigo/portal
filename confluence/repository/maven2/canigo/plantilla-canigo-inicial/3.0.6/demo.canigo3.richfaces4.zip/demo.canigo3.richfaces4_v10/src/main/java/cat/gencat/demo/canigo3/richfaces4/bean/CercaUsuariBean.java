package cat.gencat.demo.canigo3.richfaces4.bean;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;


import cat.gencat.demo.canigo3.richfaces4.bean.model.TbNavegacio;
import cat.gencat.demo.canigo3.richfaces4.service.AriadnaService;
import cat.gencat.demo.canigo3.richfaces4.service.UsuariService;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Controller("cercaUsuariBean")
@Scope("singleton")
@Lazy
public class CercaUsuariBean {

	private DataModel model;
	private String midaTaula;
	private String numeroRows;
	
	public DataModel navegacio; 
	public static final int MAX_PAGE = 10;
	
	//Injecci� de depend�ncia del Service creat
	@Autowired
	private UsuariService service;
	@Autowired
	private AriadnaService ariadnaService;
	
	//Dades Cerca
	@Size(min=3, max=12)
	private String usuariNom;
	
	private String usuariCognoms;
	private String usuariCodi;
	private String usuariTitol;
	private String dataDesde;
	private String dataFinsa;
	
	@NotNull(message="Seleccionar una opci�!")
	private String opcio = null;
	
	public String getOpcio() {
		return opcio;
	}

	public void setOpcio(String opcio) {
		this.opcio = opcio;
	}

	public String getDataDesde() {
		return dataDesde;
	}

	public void setDataDesde(String dataDesde) {
		this.dataDesde = dataDesde;
	}

	public String getDataFinsa() {
		return dataFinsa;
	}

	public void setDataFinsa(String dataFinsa) {
		this.dataFinsa = dataFinsa;
	}

	public String getUsuariCodi() {
		return usuariCodi;
	}

	public void setUsuariCodi(String usuariCodi) {
		this.usuariCodi = usuariCodi;
	}

	public String getUsuariTitol() {
		return usuariTitol;
	}

	public void setUsuariTitol(String usuariTitol) {
		this.usuariTitol = usuariTitol;
	}

	public String getUsuariNom() {
		return usuariNom;
	}

	public void setUsuariNom(String usuariNom) {
		this.usuariNom = usuariNom;
	}

	public String getUsuariCognoms() {
		return usuariCognoms;
	}

	public void setUsuariCognoms(String usuariCognoms) {
		this.usuariCognoms = usuariCognoms;
	}
	
	public String getNumeroRows() {
		return numeroRows;
	}

	public void setNumeroRows(String numeroRows) {
		this.numeroRows = numeroRows;
	}
	
	public String getMidaTaula() {
		return midaTaula;
	}

	public void setMidaTaula(String midaTaula) {
		this.midaTaula = midaTaula;
	}
	
	//*************************************** Accions de Cerca *******************************************
	public DataModel getUsuarisCerca() {
		model = new ListDataModel(service.cercaUsuaris(this.usuariNom, this.usuariCognoms));
		
		//C�lcul de la mida que ha de tindre la taula en funci� de les files mostrades
		int midaTaulaInt = 42; //mida m�nima de la taula
		if (model.getRowCount() >= MAX_PAGE) {
			midaTaulaInt = midaTaulaInt + MAX_PAGE * 22;
		} else {
			midaTaulaInt = midaTaulaInt + model.getRowCount() * 22;
		}
		midaTaula = midaTaulaInt + "px";
		
		return model;
	}
	
	public void cercaDummy() {
		System.out.println("[CercaUsuariBean][cercaDummy][INI]");
		//TODO 1
		System.out.println("[CercaUsuariBean][cercaDummy][FIN]");
	}
	
	public void borrafiltresDummy() {
		System.out.println("[CercaUsuariBean][borrafiltresDummy][INI]");
		//TODO 1
		System.out.println("[CercaUsuariBean][borrafiltresDummy][FIN]");
	}
	
	//****************************************** Accions de Navegacio *************************************
	
	public DataModel getNavegacio() {
		//String navegacio = null;
		List<TbNavegacio> nav = null;
		try {
			nav = ariadnaService.getNavegacio(0);
			navegacio = (DataModel) nav;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return navegacio;
	}
	
}
