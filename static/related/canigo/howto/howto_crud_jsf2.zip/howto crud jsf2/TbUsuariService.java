package cat.gencat.crudBasic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cat.gencat.crudBasic.dao.TbUsuariDAO;
import cat.gencat.crudBasic.model.TbUsuaris;


//TODO 3 Canvi del nom del Servei
@Service("usuariService")
@Lazy
public class TbUsuariService {
	//TODO 4 Canviar el dao a injectar
	@Autowired
	private TbUsuariDAO dao;
	
	//TODO 5 Per a cadascun dels m�todes pasar com a par�metre 
	public void altaUsuari(TbUsuaris usuari) {
		dao.save(usuari);
	}
	
	public void guardaUsuari(TbUsuaris usuari) {
		dao.update(usuari);
	}
	
	public void eliminaUsuari(TbUsuaris usuari) {
		dao.delete(usuari);
	}
	
	public List<TbUsuaris> getLlistaUsuaris(String filter) {
		return dao.findFiltered(filter);
	}
}
