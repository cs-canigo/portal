package cat.gencat.formacio.components;

import org.richfaces.model.TreeNodeImpl;

public class DefaultCanigoTreeNodeImpl extends TreeNodeImpl {
	private String data;
	
	private DefaultCanigoTreeNodeImpl parent;

	public DefaultCanigoTreeNodeImpl getParent() {
		return parent;
	}

	public void setParent(DefaultCanigoTreeNodeImpl parent) {
		this.parent = parent;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}
