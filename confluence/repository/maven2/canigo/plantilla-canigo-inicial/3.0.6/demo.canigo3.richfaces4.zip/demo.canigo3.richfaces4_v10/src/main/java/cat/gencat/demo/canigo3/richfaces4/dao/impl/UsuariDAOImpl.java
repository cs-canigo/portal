package cat.gencat.demo.canigo3.richfaces4.dao.impl;

import java.util.HashMap;
import java.util.List;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbUsuaris;
import cat.gencat.demo.canigo3.richfaces4.dao.UsuariDAO;

public class UsuariDAOImpl extends JPAGenericDaoImpl<TbUsuaris, Integer> implements UsuariDAO{

	public List<TbUsuaris> cercaUsuaris(String usuariNom, String usuariCognoms) {
		
		List<TbUsuaris> cerca = null;
		
		try {
			
			
			if (usuariNom != null && usuariNom.compareTo("") != 0) {
				if (usuariCognoms != null && usuariCognoms.compareTo("") != 0) {
					HashMap<String, String> params1 = new HashMap<String, String>();
					params1.put("nomUsuari", "%" + usuariNom + "%");
					params1.put("cognomsUsuari", "%" + usuariCognoms + "%");
					cerca = findByNamedQueryAndNamedParams("findUsuarisNomCognom", params1);
				} else {
					HashMap<String, String> params2 = new HashMap<String, String>();
					params2.put("nomUsuari", "%" + usuariNom + "%");
					cerca = findByNamedQueryAndNamedParams("findUsuarisNom", params2);
				}
			} else {
				if (usuariCognoms != null && usuariCognoms.compareTo("") != 0) {
					HashMap<String, String> params3 = new HashMap<String, String>();
					params3.put("cognomsUsuari", "%" + usuariCognoms + "%");
					cerca = findByNamedQueryAndNamedParams("findUsuarisCognom", params3);
				} else {
					cerca = findAll();
				}
			}
				
			return cerca;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
