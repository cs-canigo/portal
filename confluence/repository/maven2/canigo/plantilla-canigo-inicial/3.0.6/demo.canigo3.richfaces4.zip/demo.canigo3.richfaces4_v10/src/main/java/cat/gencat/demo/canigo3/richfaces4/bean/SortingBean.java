package cat.gencat.demo.canigo3.richfaces4.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.richfaces.component.SortOrder;
import org.springframework.stereotype.Controller;

@Controller("sortingBean")
public class SortingBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//private Map<String, SortOrder> sortOrdersMultiple = new HashMap<String, SortOrder>();
	private Map<String, SortOrder> sortOrders = new HashMap<String, SortOrder>();
	//private List<String> sortPriorities = new ArrayList<String>();
	private static final String SORT_PROPERTY = "sortProperty";
	
//	public Map<String, SortOrder> getSortOrdersMultiple() {
//		return sortOrdersMultiple;
//	}

//	public void setSortOrdersMultiple(Map<String, SortOrder> sortOrdersMultiple) {
//		this.sortOrdersMultiple = sortOrdersMultiple;
//	}

	public Map<String, SortOrder> getSortOrders() {
		return sortOrders;
	}

//	public void setSortOrders(Map<String, SortOrder> sortOrders) {
//		this.sortOrders = sortOrders;
//	}

//	public List<String> getSortPriorities() {
//		return sortPriorities;
//	}

//	public void setSortPriorities(List<String> sortPriorities) {
//		this.sortPriorities = sortPriorities;
//	}
	
	private void modifySortProperty(Map<String, SortOrder> orders, String sortProperty, SortOrder currentOrder) {
		if ((currentOrder == null) || (currentOrder == SortOrder.ascending)) {
			orders.put(sortProperty, SortOrder.descending);
		} else {
			orders.put(sortProperty, SortOrder.ascending);
		}
	}
			
//	public void resetSorting() {
//		this.sortOrdersMultiple.clear();
//		this.sortPriorities.clear();
//	}
		
	private String getSortProperty() {
		String sortProperty = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(SORT_PROPERTY);
		return sortProperty;
	}
		
//	public void sortMultiple() {
//		String sortProperty = getSortProperty();
//		SortOrder currentOrder = sortOrdersMultiple.get(sortProperty);
//		modifySortProperty(sortOrdersMultiple, sortProperty, currentOrder);
//		if (!sortPriorities.contains(sortProperty)){
//			sortPriorities.add(sortProperty);
//		}
//	}
	
	public void sort() {
		String sortProperty = getSortProperty();
		SortOrder currentOrder = sortOrders.get(sortProperty);
		sortOrders.clear();
		modifySortProperty(sortOrders, sortProperty,currentOrder);
	}
}
