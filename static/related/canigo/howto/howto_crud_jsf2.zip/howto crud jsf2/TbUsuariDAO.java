package cat.gencat.crudBasic.dao;

import java.util.List;

import cat.gencat.crudBasic.model.TbUsuaris;
import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;

//TODO 1 Cal inicialitzar el constructor de la interf�cie amb l'objecte sobre el que es vol realitzar el CRUD, i el tipus de retorn del m�tode findFiltered
public interface TbUsuariDAO extends GenericDAO<TbUsuaris, Integer> {

	public List<TbUsuaris> findFiltered(String filter);
	
}