package cat.gencat.demo.canigo3.richfaces4.dao;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;

public interface MaquinaDAO extends GenericDAO<TbMaquines, Integer> {
	
}
