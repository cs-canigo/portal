package cat.gencat.demo.canigo3.richfaces4.dao.impl;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;
import cat.gencat.demo.canigo3.richfaces4.dao.MaquinaDAO;

public class MaquinaDAOImpl extends JPAGenericDaoImpl<TbMaquines, Integer> implements MaquinaDAO{

}
