package cat.gencat.demo.canigo3.richfaces4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbNavegacio;
import cat.gencat.demo.canigo3.richfaces4.dao.AriadnaDAO;

//TODO 3 Canvi del nom del Servei
@Service("ariadnaService")
@Lazy
public class AriadnaService {

	//TODO 4 Canviar el dao a injectar
	@Autowired
	private AriadnaDAO dao;

	public List<TbNavegacio> getNavegacio() {
		return dao.findAll();
	}

	public List<TbNavegacio> getNavegacio(int idNavegacio) {
		return dao.cercaNavegacio(idNavegacio);
	}
}
