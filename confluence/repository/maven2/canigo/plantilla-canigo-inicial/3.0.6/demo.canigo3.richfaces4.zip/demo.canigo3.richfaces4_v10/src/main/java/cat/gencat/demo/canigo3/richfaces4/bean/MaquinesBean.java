package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;
import cat.gencat.demo.canigo3.richfaces4.service.MaquinaService;


@Controller("maquinesBean")
@Scope("singleton")
public class MaquinesBean implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3444950887991109517L;
	private DataModel model;
	private boolean visualitzarBotoAfegir = true;
	private boolean visualitzarFormulariAlta = false;
	private boolean visualitzarFormulariModificacio = false;

	public boolean isVisualitzarBotoAfegir() {
		return visualitzarBotoAfegir;
	}

	public void setVisualitzarBotoAfegir(boolean visualitzarBotoAfegir) {
		this.visualitzarBotoAfegir = visualitzarBotoAfegir;
	}

	public boolean isVisualitzarFormulariAlta() {
		return visualitzarFormulariAlta;
	}

	public void setVisualitzarFormulariAlta(boolean visualitzarFormulariAlta) {
		this.visualitzarFormulariAlta = visualitzarFormulariAlta;
	}

	public boolean isVisualitzarFormulariModificacio() {
		return visualitzarFormulariModificacio;
	}

	public void setVisualitzarFormulariModificacio(
			boolean visualitzarFormulariModificacio) {
		this.visualitzarFormulariModificacio = visualitzarFormulariModificacio;
	}

	// Creaci� del bean del crud que s'estigui realitzant
	private TbMaquines maquina = new TbMaquines();
	public TbMaquines getMaquina() {
		return maquina;
	}
	public void setMaquina(TbMaquines maquina) {
		this.maquina = maquina;
	}

	// Injecci� de depend�ncia del Service creat
	@Autowired
	private MaquinaService service;

	//Llistat de m�quines de suport
	DataModel modelMaquines2;
	
	//ListShutle listas
	List<TbMaquines> maquinesNoDisponibles = new ArrayList<TbMaquines>();
	List<TbMaquines> maquinesDisponibles = new ArrayList<TbMaquines>();

	public List<TbMaquines> getMaquinesNoDisponibles() {
		return service.getLlistaMaquinesNoDisponibles();
	}

	public void setMaquinesNoDisponibles(List<TbMaquines> maquinesNoDisponibles) {
		this.maquinesNoDisponibles = maquinesNoDisponibles;
	}

	public List<TbMaquines> getMaquinesDisponibles() {
		return service.getLlistaMaquinesDisponibles();
	}

	public void setMaquinesDisponibles(List<TbMaquines> maquinesDisponibles) {
		this.maquinesDisponibles = maquinesDisponibles;
	}

	/**
	 * altaMaquina
	 */
	public void altaMaquina() {
		this.maquina.setIdMaquina(null);
		service.altaMaquina(this.maquina);
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		FacesContext.getCurrentInstance().addMessage(
				"formulariLlistat",
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"S'ha donat d'alta la m�quina "
								+ this.maquina.getNomMaquina(), null));
	}

	/**
	 * actualitzarDisponibilitats
	 */
	public void actualitzarDisponibilitats() {
		service.actualitzarDisponibilitats(maquinesDisponibles, maquinesNoDisponibles);
		maquinesDisponibles = service.getLlistaMaquinesDisponibles();
		maquinesNoDisponibles = service.getLlistaMaquinesNoDisponibles();
		FacesContext.getCurrentInstance().addMessage(
				"formulariLlistat2",
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"S'ha actualitzat la disponibilitat de les m�quines", null));
	}
	
	/**
	 * modificarMaquina
	 */
	public void modificarMaquina() {
		service.guardaMaquina(this.maquina);
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		FacesContext.getCurrentInstance().addMessage(
				"formulariLlistat",
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"S'ha modificat la m�quina", null));
	}

	/**
	 * eliminarMaquina
	 */
	public void eliminarMaquina() {
		TbMaquines maquina = (TbMaquines) model.getRowData();
		service.eliminaMaquina(maquina);
		FacesContext.getCurrentInstance().addMessage(
				"formulariLlistat",
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"S'ha eliminat la m�quina", null));
	}

	/**
	 * getMaquines
	 * @return
	 */
	public DataModel getMaquines() {
		maquinesDisponibles = service.getLlistaMaquinesDisponibles();
		maquinesNoDisponibles = service.getLlistaMaquinesNoDisponibles();
		model = new ListDataModel(service.getLlistaMaquines());
		return model;
	}

	// ***************************************Accions**************************************
	/**
	 * navigateModificarMaquina
	 */
	public void navigateModificarMaquina() {
		TbMaquines maquina = (TbMaquines) model.getRowData();
		this.visualitzarFormulariModificacio = true;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = false;
		this.maquina = maquina;
	}

	/**
	 * navigateEliminarMaquina
	 */
	public void navigateEliminarMaquina() {
		TbMaquines maquina = (TbMaquines) model.getRowData();
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		this.maquina = maquina;
	}

	/**
	 * visualitzaAltaForm
	 */
	public void visualitzaAltaForm() {
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = true;
		this.visualitzarBotoAfegir = false;
	}
	
	/**
	 * cancelaModificacio
	 */
	public void cancelaModificacio() {
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
	}
	
	/**
	 * getStatus
	 */
	public void getStatus() {
		service.checkStatus();
		FacesContext.getCurrentInstance().addMessage(
				"idForm",
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"S'ha actualitzat la connectivitat de les m�quines", null));
	}
	
	/**
	 * M�tode a executar per l'autocomplete
	 * @param cerca
	 * @return
	 */
	public List<String> nomMaquinaAutocomplete(String cerca) {
		ArrayList<String> result = new ArrayList<String>();
		for (Iterator<TbMaquines> iterator = getMaquinesNoDisponibles().iterator(); iterator.hasNext();) {
			TbMaquines maquina = (TbMaquines) iterator.next();
			if (maquina.getNomMaquina().startsWith(cerca)) {
				result.add(maquina.getNomMaquina());
			}
		}
		
	    return result;
	}
	
	
/*********************************************M�todes Dummy*********************************************************
	/*
	 * esborrarDummy
	 */
	public void esborrarDummy() {
		System.out.println("[MaquinesBean][esborrarDummy]");
	}
	
	/*
	 * exportarDummy
	 */
	public void exportarDummy() {
		System.out.println("[MaquinesBean][exportarDummy]");
	}
	
	/*
	 * aprovaDummy
	 */
	public void aprovaDummy() {
		System.out.println("[MaquinesBean][aprovaDummy]");
	}
	
	/*
	 * despublicaDummy
	 */
	public void despublicaDummy() {
		System.out.println("[MaquinesBean][despublicaDummy]");
	}
	
	/*
	 * publicaDummy
	 */
	public void publicaDummy() {
		System.out.println("[MaquinesBean][publicaDummy]");
	}
	
}
