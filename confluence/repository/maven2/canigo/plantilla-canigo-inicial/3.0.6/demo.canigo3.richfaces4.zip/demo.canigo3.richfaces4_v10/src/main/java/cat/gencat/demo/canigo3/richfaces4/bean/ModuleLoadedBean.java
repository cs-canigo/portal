package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cat.gencat.ctti.canigo.arch.core.utils.jmx.IModuleIdentificationMbean;

@Component("moduleLoadedBean")
@Scope("singleton")
@Lazy
public class ModuleLoadedBean {
		
	private IModuleIdentificationMbean moduleService = null;
	
	@Autowired
	public void setModuleIdentification(IModuleIdentificationMbean service){
		this.moduleService = service;
	}
	
	/**
	 * Return runtime modules
	 * @return
	 */
	public Map<String,List<String>> getItems() {
		   return this.moduleService.getRuntimeModules();
	}
	
	/**
	 * Get items from service
	 * @return
	 */
	public List<String> getItemKeys() {
		List<String> keys = new ArrayList<String>();
		keys.addAll(getItems().keySet());
		return keys;
	}
	
}
