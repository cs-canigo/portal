package cat.gencat.demo.canigo3.richfaces4.dao.impl;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbCluster;
import cat.gencat.demo.canigo3.richfaces4.dao.ClusterDAO;

public class ClusterDAOImpl extends JPAGenericDaoImpl<TbCluster, Integer> implements ClusterDAO{

}
