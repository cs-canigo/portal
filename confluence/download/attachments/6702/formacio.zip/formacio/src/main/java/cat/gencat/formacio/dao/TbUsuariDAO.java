package cat.gencat.formacio.dao;

import java.util.List;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;
import cat.gencat.formacio.model.TbUsuaris;

//TODO 1 Cal inicialitzar el constructor de la interf�cie amb l'objecte sobre el que es vol realitzar el CRUD.
public interface TbUsuariDAO extends GenericDAO<TbUsuaris, Integer> {

	public List<TbUsuaris> findFiltered(String filter);
	
}