package cat.gencat.demo.canigo3.richfaces4.dao;

import java.util.List;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbUsuaris;

public interface UsuariDAO extends GenericDAO<TbUsuaris, Integer> {

	List<TbUsuaris> cercaUsuaris(String usuariNom, String usuariCognoms);
	
}
