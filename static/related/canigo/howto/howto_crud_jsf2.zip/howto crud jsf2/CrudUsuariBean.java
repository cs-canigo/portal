package cat.gencat.crudBasic.bean;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cat.gencat.crudBasic.model.TbUsuaris;
import cat.gencat.crudBasic.service.TbUsuariService;
import cat.gencat.ctti.canigo.arch.core.exceptions.ExceptionDetails;
import cat.gencat.ctti.canigo.arch.core.exceptions.WrappedCheckedException;
import cat.gencat.ctti.canigo.arch.core.i18n.I18nResourceBundleMessageSource;

//TODO 6 Modificaci� del nom del Manage Bean
@Component("crudUsuariBean")
@Scope(value="session")
public class CrudUsuariBean {

	private static final Log log = LogFactory.getLog(CrudUsuariBean.class);
	
	@Autowired
    private I18nResourceBundleMessageSource i18n;
	
	// TODO 8 Injecci� de depend�ncia del Service creat
	@Autowired
	private TbUsuariService service;
	
	private DataModel<TbUsuaris> model;

	// TODO 7 creaci� del bean del crud que s'estigui realitzant
	private TbUsuaris usuari = new TbUsuaris();

	private String filter;
	
	private boolean visualitzarModificacio = false;
	private boolean refrescarUsuaris = true;
	
	public void navigateAltaUsuari() {
		this.usuari = new TbUsuaris();
	}
	
	// TODO 9 Modificaci� dels m�todes en funci� del bean a modificar.
	public void altaUsuari() {
		if(log.isDebugEnabled()) {
			log.debug("Alta d'usuari");
		}

		this.refrescarUsuaris = true;
		
		this.usuari.setIdUsuari(null);
		service.altaUsuari(this.usuari);

		//Buidem els camps del formulari
		this.usuari=new TbUsuaris();
	}

	public void modificarUsuari() {
		if(log.isDebugEnabled()) {
			log.debug("Modificar usuari");
		}
		
		this.visualitzarModificacio = true;
		this.refrescarUsuaris = true;
		service.guardaUsuari(this.usuari);
	}

	public void eliminarUsuari() {
		if(log.isDebugEnabled()) {
			log.debug("Eliminar usuari");
		}
		
		this.usuari = (TbUsuaris) model.getRowData();
		
		this.visualitzarModificacio = false;
		this.refrescarUsuaris = true;
		service.eliminaUsuari(this.usuari);
		this.usuari = new TbUsuaris();
	}

	public DataModel<TbUsuaris> getUsuaris() {
		if( this.refrescarUsuaris ) {
			if(log.isDebugEnabled()) {
				log.debug("Llistar usuaris");
			}
			
			this.visualitzarModificacio = false;
			model = new ListDataModel<TbUsuaris>(service.getLlistaUsuaris(filter));
		}
		return model;
	}

	public void navigateModificarUsuari() {
		TbUsuaris usuari = (TbUsuaris) model.getRowData();
		this.visualitzarModificacio = true;
		this.usuari = usuari;
		this.refrescarUsuaris = false;
	}

	public boolean getVisualitzarModificacio() {
		return visualitzarModificacio;
	}

	public void setVisualitzarModificacio(boolean visualitzarModificacio) {
		this.visualitzarModificacio = visualitzarModificacio;
	}

	public TbUsuaris getUsuari() {
		return usuari;
	}

	public void setUsuari(TbUsuaris usuari) {
		this.usuari = usuari;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public boolean isRefrescarUsuaris() {
		return refrescarUsuaris;
	}

	public void setRefrescarUsuaris(boolean refrescarUsuaris) {
		this.refrescarUsuaris = refrescarUsuaris;
	}

}
