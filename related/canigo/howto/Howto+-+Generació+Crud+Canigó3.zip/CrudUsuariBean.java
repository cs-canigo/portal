package cat.gencat.dgac.bean;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cat.gencat.dgac.domain.beans.TUsuari;
import cat.gencat.dgac.service.CrudService;

//TODO 6 Modificaci� del nom del Manage Bean
@Controller("crudUsuariBean")
@Scope("request")
@Lazy
public class CrudUsuariBean {
		
	private DataModel model;
	private boolean visualitzarModificacio = false;

	public boolean getVisualitzarModificacio() {
		return visualitzarModificacio;
	}

	public void setVisualitzarModificacio(boolean visualitzarModificacio) {
		this.visualitzarModificacio = visualitzarModificacio;
	}

	//TODO 7 creaci� del bean del crud que s'estigui realitzant
	private TUsuari usuari = new TUsuari();
	
	public TUsuari getUsuari() {
		return usuari;
	}

	public void setUsuari(TUsuari usuari) {
		this.usuari = usuari;
	}

	//TODO 8 Injecci� de depend�ncia del Service creat
	@Autowired
	private CrudService service;
	
	//TODO 9 Modificaci� dels m�todes en funci� del bean a modificar.
	public void altaUsuari() {
		this.usuari.setIdUsuari(null);
		service.altaUsuari(this.usuari);
		FacesContext.getCurrentInstance().addMessage("formulariAlta", new FacesMessage(FacesMessage.SEVERITY_INFO, "S'ha donat d'alta l'usuari " + this.usuari.getNom(), null));
	}
	public void modificarUsuari() {
		this.visualitzarModificacio = true;
		service.guardaUsuari(this.usuari);
		FacesContext.getCurrentInstance().addMessage("formulariModificacio", new FacesMessage(FacesMessage.SEVERITY_INFO, "S'ha modificat l'usuari", null));
	}
	public void eliminarUsuari() {
		this.usuari = (TUsuari) model.getRowData();
		this.visualitzarModificacio = false;
		service.eliminaUsuari(this.usuari);
		FacesContext.getCurrentInstance().addMessage("formulariModificacio", new FacesMessage(FacesMessage.SEVERITY_INFO, "S'ha eliminat l'usuari", null));
	}
	public DataModel getUsuaris() {
		model = new ListDataModel(service.getLlistaUsuaris(this.usuari));
		return model;
	}
	
	public String go() {
		FacesContext context = FacesContext.getCurrentInstance();
		String forward = (String) context.getExternalContext().getRequestParameterMap().get("accio");
		return forward;
	}

	public void navigateModificarUsuari() {
		TUsuari usuari = (TUsuari) model.getRowData();
		this.visualitzarModificacio = true;
		this.usuari = usuari;
	}
	public void navigateEliminarUsuari() {
		TUsuari usuari = (TUsuari) model.getRowData();
		this.visualitzarModificacio = false;
		this.usuari = usuari;
	}
}
