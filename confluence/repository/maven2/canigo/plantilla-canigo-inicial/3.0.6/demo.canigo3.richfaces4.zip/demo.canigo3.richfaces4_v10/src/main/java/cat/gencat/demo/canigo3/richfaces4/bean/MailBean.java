package cat.gencat.demo.canigo3.richfaces4.bean;
//package cat.gencat.demo.canigo.spec.bean;
//
//import javax.faces.application.FacesMessage;
//import javax.faces.context.FacesContext;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Scope;
//import org.springframework.stereotype.Component;
//
//import cat.gencat.ctti.canigo.arch.core.i18n.I18nResourceBundleMessageSource;
//import cat.gencat.ctti.canigo.arch.support.mailing.MailService;
//
//@Component("mailBean")
//@Scope("request")
//public class MailBean {
//
//	private MailService service;
//	private String to;
//	private String subject;
//	private String from;
//	private String cc;
//	private String cco;
//	private String body;
//
//	@Autowired
//	private I18nResourceBundleMessageSource messageResource;
//	private String result;
//
//	public String getResult(){
//		if(result!=null){
//			return messageResource.getMessage(result); 		
//		} else { 			
//			return ""; 		
//		}
//	}
//
//	public String getTo() { 		
//		return to; 	
//	}
//	public void setTo(String to) { 		
//		this.to = to; 	
//	}
//	public String getSubject() { 		
//		return subject; 	
//	}
//	public void setSubject(String subject) { 	
//		this.subject = subject; 	
//	}
//	public String getFrom() {
//		return from; 	
//	}
//	public void setFrom(String from) {
//		this.from = from; 	
//	}
//	public String getCc() { 		
//		return cc; 	
//	}
//	public void setCc(String cc) { 		
//		this.cc = cc; 	
//	}
//	public String getCco() { 		
//		return cco; 	
//	}
//	public void setCco(String cco) { 		
//		this.cco = cco; 	
//	}
//	public String getBody() { 		
//		return body; 	
//	}
//	public void setBody(String body) {
//		this.body = body; 	
//	}
//	public MailService getService() {
//		return service; 	
//	}
//	
//	@Autowired
//	public void setService(MailService service)	{
//		this.service = service; 	
//	}
//
//	/**
//	 * SendMail
//	 * @return
//	 */
//	public String sendMail() {
//		try{
//			this.service.send(getFrom(), getSubject(), getBody(), false, getTo());
//			FacesContext.getCurrentInstance().addMessage("mailingForm", new FacesMessage(
//					FacesMessage.SEVERITY_INFO, messageResource.getMessage("mailingSuccces"), null));
//			this.result = "mailingSuccces";
//		} catch (Exception e) {
//			FacesContext.getCurrentInstance().addMessage("mailingForm", new FacesMessage(
//					FacesMessage.SEVERITY_ERROR, e.getMessage(), null)); 			
//			this.result = "mailingError";
//		} return "mail";
//	}
//
//	//
//	public String sendMailMock() {
//		FacesContext.getCurrentInstance().addMessage("mailingForm", new FacesMessage(
//				FacesMessage.SEVERITY_INFO, messageResource.getMessage("mailingSuccces"), null));
//		this.result = "mailingSuccces";
//		return "mail";
//	}
//}
