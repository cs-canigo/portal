package cat.gencat.demo.canigo3.richfaces4.bean;

import java.io.IOException;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;


@Component("statusBean")
@Scope("singleton")
@Lazy
public class CheckStatusBean {
	
	public void check() throws IOException{

	}
}