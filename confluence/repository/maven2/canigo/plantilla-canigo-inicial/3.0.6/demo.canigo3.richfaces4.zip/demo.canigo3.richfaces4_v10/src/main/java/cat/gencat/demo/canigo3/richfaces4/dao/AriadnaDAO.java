package cat.gencat.demo.canigo3.richfaces4.dao;

import java.util.List;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.GenericDAO;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbNavegacio;

public interface AriadnaDAO extends GenericDAO<TbNavegacio, Integer> {

	List<TbNavegacio> cercaNavegacio(int idNavegacio);

}
