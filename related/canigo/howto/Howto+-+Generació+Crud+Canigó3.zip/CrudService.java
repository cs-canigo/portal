package cat.gencat.dgac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cat.gencat.dgac.dao.UsuariDAO;
import cat.gencat.dgac.domain.beans.TUsuari;

//TODO 3 Canvi del nom del Servei
@Service("crudService")
@Lazy
public class CrudService {
	//TODO 4 Canviar el dao a injectar
	@Autowired
	private UsuariDAO dao;
	
	//TODO 5 Per a cadascun dels m�todes pasar com a par�metre 
	public void altaUsuari(TUsuari usuari) {
		dao.save(usuari);
	}
	
	public void guardaUsuari(TUsuari usuari) {
		dao.update(usuari);
	}
	
	public void eliminaUsuari(TUsuari usuari) {
		dao.delete(usuari);
	}
	
	public List<TUsuari> getLlistaUsuaris(TUsuari usuari) {
		return dao.findAll();
	}
}
