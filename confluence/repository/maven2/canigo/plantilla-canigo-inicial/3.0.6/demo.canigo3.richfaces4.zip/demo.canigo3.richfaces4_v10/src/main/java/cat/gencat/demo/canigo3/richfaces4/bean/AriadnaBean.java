package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.List;

import javax.faces.model.DataModel;

import org.springframework.beans.factory.annotation.Autowired;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbNavegacio;
import cat.gencat.demo.canigo3.richfaces4.service.AriadnaService;

public class AriadnaBean {

	private DataModel model;
	
	@Autowired
	private AriadnaService service;
	
	public List<TbNavegacio> getNavegacio(int idNavegacio) {
		return service.getNavegacio(idNavegacio);
	}
	
	public List<TbNavegacio> getLlista() {
		return service.getNavegacio();
	}
}
