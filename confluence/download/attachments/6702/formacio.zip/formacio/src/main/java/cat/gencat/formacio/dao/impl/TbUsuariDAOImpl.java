package cat.gencat.formacio.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.formacio.dao.TbUsuariDAO;
import cat.gencat.formacio.model.TbUsuaris;

//TODO 2 Modificar TUsuari per l'objecte de mapping que es vulgui realitzar el crud.
public class TbUsuariDAOImpl extends JPAGenericDaoImpl<TbUsuaris, Integer>
		implements TbUsuariDAO {

	@SuppressWarnings("unchecked")
	public List<TbUsuaris> findFiltered(String filter) {
		Session session = (Session) this.getEntityManager().getDelegate();
		Criteria crit = session.createCriteria(TbUsuaris.class);
		if (filter != null && !"".equals(filter)) {
			crit.add(Restrictions.or(Restrictions.or(Restrictions.or(
					Restrictions.like("nom", "%" + filter + "%"),
					Restrictions.like("cognoms", "%" + filter + "%")),
					Restrictions.like("email", "%" + filter + "%")),
					Restrictions.like("nif", "%" + filter + "%")));
		}
		
		return (List<TbUsuaris>) crit.list();
	}

}
