package cat.gencat.demo.canigo3.richfaces4.bean.model;

public class Option {

	private static final long serialVersionUID = -3444345887991109517L;
	
	public String name;
	public String style;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	
	public Option(String name, String style) {
		this.name = name;
		this.style = style;
	}
	
}
