drop table TB_USUARIS;
drop table TB_DEPARTAMENTS;