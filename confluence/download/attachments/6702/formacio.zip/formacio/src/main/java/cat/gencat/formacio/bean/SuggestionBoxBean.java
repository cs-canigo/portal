package cat.gencat.formacio.bean;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cat.gencat.formacio.model.City;

@Component("suggestionBoxBean")  
@Scope("request")
public class SuggestionBoxBean {  
	private String name;
    private String cityId="";  
  
    private List<City> cityList = new ArrayList<City>();  
    private List<City> returnList = new ArrayList<City>();  
  
    public List<City> suggestCity(String cityName) {  
    //public List<City> suggestCity(Object object) {  
        //String cityName = (String) object;  
        returnList.clear();  
        /* ________________Logic to filter data_____________ */  
        for (int i = 0; i < cityList.size(); i++) {  
            if (cityList.get(i).getCityName().startsWith(cityName))  
                returnList.add(cityList.get(i));  
        }  
        return returnList;  
    }  
  
    public String printCity() {  
        System.out.println("City = " + cityId);  
        return null;  
    }  
  
    public String getCityId() {  
        return cityId;  
    }  
  
    public void setCityId(String cityId) {  
        this.cityId = cityId;  
    }  
  
    public List<City> getCityList() {  
        return cityList;  
    }  
  
    public void setCityList(List<City> cityList) {  
        this.cityList = cityList;  
    }  
  
    public SuggestionBoxBean() {  
    	cityList.add(new City("Ahigal (C�ceres)"));
    	cityList.add(new City("Alcal� de Henares (Madrid)"));
    	cityList.add(new City("Alcobendas (Madrid)"));
    	cityList.add(new City("Alcorc�n (Madrid)"));
    	cityList.add(new City("Aldea del Fresno (Madrid)"));
    	cityList.add(new City("Albacete"));
    	cityList.add(new City("Algeciras (C�diz)"));
    	cityList.add(new City("Alicante"));
    	cityList.add(new City("Almer�a"));
    	cityList.add(new City("Altea (Alicante)"));
    	cityList.add(new City("Aranjuez (Madrid)"));
    	cityList.add(new City("Armilla (Granada)"));
    	cityList.add(new City("Arroyomolinos (Madrid)"));
    	cityList.add(new City("Astorga (Le�n)"));
    	cityList.add(new City("�vila"));
    	cityList.add(new City("Ayamonte (Huelva)"));
    	cityList.add(new City("Azuel (C�rdoba)"));
    	cityList.add(new City("Badajoz"));
    	cityList.add(new City("Badalona (Barcelona)"));
    	cityList.add(new City("Bail�n (Ja�n)"));
    	cityList.add(new City("Ba�os de Montemayor (C�ceres)"));
    	cityList.add(new City("Barcarrota (Badajoz)"));
    	cityList.add(new City("Barcelona"));
    	cityList.add(new City("Biescas (Huesca)"));
    	cityList.add(new City("Bilbao (Vizcaya)"));
    	cityList.add(new City("Brunete (Madrid)"));
    	cityList.add(new City("Burgos"));
    	cityList.add(new City("C�ceres"));
    	cityList.add(new City("C�diz"));
    	cityList.add(new City("Calatayud (Zaragoza)"));
    	cityList.add(new City("Cartagena (Murcia)"));
    	cityList.add(new City("Cartaya (Huelva)"));
    	cityList.add(new City("Castell�n"));
    	cityList.add(new City("Cedeira (La Coru�a)"));
    	cityList.add(new City("Cerceda (Madrid)"));
    	cityList.add(new City("Cercedilla (Madrid)"));
    	cityList.add(new City("Ceuta"));
    	cityList.add(new City("Ciudad Real"));
    	cityList.add(new City("Ciudad Rodrigo (Salamanca)"));
    	cityList.add(new City("C�rdoba"));
    	cityList.add(new City("Coria (C�ceres)"));
    	cityList.add(new City("Coru�a, La"));
    	cityList.add(new City("Cuenca"));
    	cityList.add(new City("Don Benito (Badajoz)"));
    	cityList.add(new City("Dos Hermanas (Sevilla)"));
    	cityList.add(new City("Elche (Alicante)"));
    	cityList.add(new City("Eljas (C�ceres)"));
    	cityList.add(new City("Fuenlabrada (Madrid)"));
    	cityList.add(new City("Gerona"));
    	cityList.add(new City("Getafe (Madrid)"));
    	cityList.add(new City("Gibrale�n (Huelva)"));
    	cityList.add(new City("Gij�n (Asturias)"));
    	cityList.add(new City("Granada"));
    	cityList.add(new City("La Granja de Granadilla (C�ceres)"));
    	cityList.add(new City("Guadalajara"));
    	cityList.add(new City("Guijo de Granadilla (C�ceres)"));
    	cityList.add(new City("Hernani (Guip�zcoa)"));
    	cityList.add(new City("Herv�s (C�ceres)"));
    	cityList.add(new City("L'Hospitalet de l'Infant (Tarragona)"));
    	cityList.add(new City("L'Hospitalet de Llobregat (Barcelona)"));
    	cityList.add(new City("Hoyo de Manzanares (Madrid)"));
    	cityList.add(new City("Huelva"));
    	cityList.add(new City("Huesca"));
    	cityList.add(new City("Isla Cristina (Huelva)"));
    	cityList.add(new City("Jaca (Huesca)"));
    	cityList.add(new City("Ja�n"));
    	cityList.add(new City("La Jonquera (Girona)"));
    	cityList.add(new City("Legan�s (Madrid)"));
    	cityList.add(new City("Le�n"));
    	cityList.add(new City("Lepe (Huelva)"));
    	cityList.add(new City("La L�nea de la Concepci�n (C�diz)"));
    	cityList.add(new City("L�rida"));
    	cityList.add(new City("Llodio (�lava)"));
    	cityList.add(new City("Logro�o (La Rioja)"));
    	cityList.add(new City("Lugo"));
    	cityList.add(new City("Madrid"));
    	cityList.add(new City("M�laga"));
    	cityList.add(new City("Manzanares (Ciudad Real)"));
    	cityList.add(new City("Marbella (M�laga)"));
    	cityList.add(new City("Mazarr�n (Murcia)"));
    	cityList.add(new City("Mejorada del Campo (Madrid)"));
    	cityList.add(new City("Melilla"));
    	cityList.add(new City("Meco (Madrid)"));
    	cityList.add(new City("M�ntrida (Toledo)"));
    	cityList.add(new City("Miami Playa (Tarragona)"));
    	cityList.add(new City("Montehermoso (C�ceres)"));
    	cityList.add(new City("Montejo de la Sierra (Madrid)"));
    	cityList.add(new City("Moraleja (C�ceres)"));
    	cityList.add(new City("M�stoles (Madrid)"));
    	cityList.add(new City("Murcia"));
    	cityList.add(new City("Navacerrada (Madrid)"));
    	cityList.add(new City("Navalcarnero (Madrid)"));
    	cityList.add(new City("Navalmoral de la Mata (C�ceres)"));
    	cityList.add(new City("Olivenza (Badajoz)"));
    	cityList.add(new City("Orense"));
    	cityList.add(new City("Oropesa (Toledo)"));
    	cityList.add(new City("Oviedo"));
    	cityList.add(new City("Palencia"));
    	cityList.add(new City("Palma de Mallorca"));
    	cityList.add(new City("Las Palmas de Gran Canaria"));
    	cityList.add(new City("Pamplona (Vasco: Iru�a)"));
    	cityList.add(new City("Pola de Lena (Asturias)"));
    	cityList.add(new City("Pinto (Madrid)"));
    	cityList.add(new City("Plasencia (C�ceres)"));
    	cityList.add(new City("Pontevedra"));
    	cityList.add(new City("Pozuelo de Alarc�n (Madrid)"));
    	cityList.add(new City("Quijorna (Madrid)"));
    	cityList.add(new City("Reus (Tarragona)"));
    	cityList.add(new City("Ribadesella (Asturias)"));
    	cityList.add(new City("Robledo de Chavela (Madrid)"));
    	cityList.add(new City("Rota (Andaluc�a)"));
    	cityList.add(new City("Salamanca"));
    	cityList.add(new City("San Crist�bal de La Laguna (Santa Cruz de Tenerife)"));
    	cityList.add(new City("San Fernando de Henares (Madrid)"));
    	cityList.add(new City("San Lorenzo de El Escorial (Madrid)"));
    	cityList.add(new City("San Mart�n de la Vega (Madrid)"));
    	cityList.add(new City("San Mart�n de Trevejo (C�ceres)"));
    	cityList.add(new City("San Mart�n y Mudri�n (Segovia)"));
    	cityList.add(new City("San Sebasti�n (Guip�zcoa) (Vasco: Donosti)"));
    	cityList.add(new City("San Sebasti�n de los Reyes (Madrid)"));
    	cityList.add(new City("San Vicente de la Barquera (Santander)"));
    	cityList.add(new City("Santa Cruz de Tenerife"));
    	cityList.add(new City("Santander"));
    	cityList.add(new City("Santiba�ez el Alto (C�ceres)"));
    	cityList.add(new City("Santiba�ez el Bajo (C�ceres)"));
    	cityList.add(new City("Segovia"));
    	cityList.add(new City("Sevilla"));
    	cityList.add(new City("Sevilla la Nueva (Madrid)"));
    	cityList.add(new City("Soria"));
    	cityList.add(new City("Tarragona"));
    	cityList.add(new City("Teruel"));
    	cityList.add(new City("Tharsis (Huelva)"));
    	cityList.add(new City("Tres Cantos (Madrid)"));
    	cityList.add(new City("Toledo"));
    	cityList.add(new City("Torrej�n de Ardoz (Madrid)"));
    	cityList.add(new City("Torrevieja (Alicante)"));
    	cityList.add(new City("�beda (Ja�n)"));
    	cityList.add(new City("La Uni�n (Murcia)"));
    	cityList.add(new City("Valdemoro (Madrid)"));
    	cityList.add(new City("Valdeobispo (C�ceres)"));
    	cityList.add(new City("Val�ncia"));
    	cityList.add(new City("Valladolid"));
    	cityList.add(new City("Valverde del Fresno (C�ceres)"));
    	cityList.add(new City("Velilla de San Antonio (Madrid)"));
    	cityList.add(new City("Vigo (Pontevedra)"));
    	cityList.add(new City("Villablanca (Huelva)"));
    	cityList.add(new City("Villalba (Madrid)"));
    	cityList.add(new City("Villanueva del Pardillo (Madrid)"));
    	cityList.add(new City("Villaviciosa de Od�n (Madrid)"));
    	cityList.add(new City("Vitoria (�lava) (Vasco: Gasteiz)"));
    	cityList.add(new City("Zamora"));
    	cityList.add(new City("Zaragoza"));
    	cityList.add(new City("Zarauz (Guip�zcoa)"));
    	cityList.add(new City("Zarza de Granadilla (C�ceres)"));
    }
    
    public void doNothing(){
    	System.out.println("---------a4j command button pressed :: Nothing to do---------");
    }

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}  