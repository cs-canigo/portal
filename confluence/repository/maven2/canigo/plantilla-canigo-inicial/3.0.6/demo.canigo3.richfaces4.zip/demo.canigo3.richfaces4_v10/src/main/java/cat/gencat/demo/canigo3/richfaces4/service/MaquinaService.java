package cat.gencat.demo.canigo3.richfaces4.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;
import cat.gencat.demo.canigo3.richfaces4.dao.MaquinaDAO;

//TODO 3 Canvi del nom del Servei
@Service("maquinaService")
public class MaquinaService {

	//TODO 4 Canviar el dao a injectar
	@Autowired
	private MaquinaDAO dao;
	
	//TODO 5 Per a cadascun dels m�todes pasar com a par�metre 
	public void altaMaquina(TbMaquines maquina) {
		dao.save(maquina);
	}
	
	public void guardaMaquina(TbMaquines maquina) {
		dao.update(maquina);
	}
	
	public void eliminaMaquina(TbMaquines maquina) {
		dao.delete(maquina);
	}
	
	public List<TbMaquines> getLlistaMaquines() {
		return dao.findAll();
	}

	public List<TbMaquines> checkStatus() {
		
		List<TbMaquines> llista = null;
		
		try {
			llista = dao.findAll();
			for (Iterator<TbMaquines> iterator = llista.iterator(); iterator.hasNext();) {
				TbMaquines maq = (TbMaquines) iterator.next();
				Integer status = comprovarConnectivitat(maq.getIp());
				maq.setStatus(status);
				dao.update(maq);
			}
			return llista;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * M�tode que comprova la connectivitat
	 * @param ip
	 * @return
	 */
	private Integer comprovarConnectivitat(String ip) {
		double random = Math.random();
		if (random < 0.3) {
			return new Integer(0);
		}
		if ((0.3 <= random) && (random < 0.6) ) {
			return new Integer(1);
		}
		if ((0.6 <= random) && (random <= 1.0)) {
			return new Integer(2);
		}
		return 0;
	}

	/**
	 * getLlistaMaquinesDisponibles
	 * @return
	 */
	public List<TbMaquines> getLlistaMaquinesDisponibles() {
		
		List<TbMaquines> llistaRecuperada;
		ArrayList<TbMaquines> llistaRecuperadesDisponibles;
		
		try {
			llistaRecuperada = dao.findAll();
			llistaRecuperadesDisponibles = new ArrayList<TbMaquines>(); 
			for (Iterator<TbMaquines> iterator = llistaRecuperada.iterator(); iterator.hasNext();) {
				TbMaquines maquina = (TbMaquines) iterator.next();
				if (maquina.getDisponible() != null && Boolean.TRUE == maquina.getDisponible()) {
					llistaRecuperadesDisponibles.add(maquina);
				}
			}
			return llistaRecuperadesDisponibles;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * getLlistaMaquinesNoDisponibles
	 * @return
	 */
	public List<TbMaquines> getLlistaMaquinesNoDisponibles() {
		
		List<TbMaquines> llistaRecuperada;
		ArrayList<TbMaquines> llistaRecuperadesNoDisponibles;
		
		try {
			llistaRecuperada = dao.findAll();
			llistaRecuperadesNoDisponibles = new ArrayList<TbMaquines>(); 
			for (Iterator<TbMaquines> iterator = llistaRecuperada.iterator(); iterator.hasNext();) {
				TbMaquines maquina = (TbMaquines) iterator.next();
				if (maquina.getDisponible() != null && Boolean.FALSE == maquina.getDisponible()) {
					llistaRecuperadesNoDisponibles.add(maquina);
				}
			}
			return llistaRecuperadesNoDisponibles;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * getLlistaMaquinesNoDisponibles
	 * @param maquinesDisponibles
	 * @param maquinesNoDisponibles
	 */
	public void actualitzarDisponibilitats( List<TbMaquines> maquinesDisponibles,
			List<TbMaquines> maquinesNoDisponibles) {
		
		try {
			for (Iterator<TbMaquines> iterator = maquinesDisponibles.iterator(); iterator.hasNext();) {
				TbMaquines maq = (TbMaquines) iterator.next();
				if (maq.getDisponible() == Boolean.FALSE) {
					maq.setDisponible(Boolean.TRUE);
					dao.update(maq);
				}
			}
			
			for (Iterator<TbMaquines> iterator = maquinesNoDisponibles.iterator(); iterator.hasNext();) {
				TbMaquines maq = (TbMaquines) iterator.next();
				if (maq.getDisponible() == Boolean.TRUE) {
					maq.setDisponible(Boolean.FALSE);
					dao.update(maq);
				}	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
