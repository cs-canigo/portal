package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

//import org.richfaces.component.UIExtendedDataTable;
//import org.richfaces.component.html.HtmlDatascroller;
//import org.richfaces.event.DataScrollerEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbUsuaris;
import cat.gencat.demo.canigo3.richfaces4.service.UsuariService;

@Controller("usuariBean")
@Scope("singleton")
@Lazy
public class UsuariBean {
	
	private DataModel model;
	private String midaTaula;
	private String numeroRows;
	private boolean visualitzarBotoAfegir = true;
	private boolean visualitzarFormulariAlta = false;
	private boolean visualitzarFormulariModificacio = false;
	private Collection<Object> selection;
	private List<TbUsuaris> selectionItems = new ArrayList<TbUsuaris>();

	public static final int MAX_PAGE = 10;
	
	public List<TbUsuaris> getSelectionItems() {
		return selectionItems;
	}

	public void setSelectionItems(List<TbUsuaris> selectionItems) {
		this.selectionItems = selectionItems;
	}

	public Collection<Object> getSelection() {
		return selection;
	}

	public void setSelection(Collection<Object> selection) {
		this.selection = selection;
	}

	public String getNumeroRows() {
		return numeroRows;
	}

	public void setNumeroRows(String numeroRows) {
		this.numeroRows = numeroRows;
	}

	public boolean isVisualitzarBotoAfegir() {
		return visualitzarBotoAfegir;
	}

	public void setVisualitzarBotoAfegir(boolean visualitzarBotoAfegir) {
		this.visualitzarBotoAfegir = visualitzarBotoAfegir;
	}

	public boolean isVisualitzarFormulariAlta() {
		return visualitzarFormulariAlta;
	}

	public void setVisualitzarFormulariAlta(boolean visualitzarFormulariAlta) {
		this.visualitzarFormulariAlta = visualitzarFormulariAlta;
	}

	public boolean isVisualitzarFormulariModificacio() {
		return visualitzarFormulariModificacio;
	}

	public void setVisualitzarFormulariModificacio(
			boolean visualitzarFormulariModificacio) {
		this.visualitzarFormulariModificacio = visualitzarFormulariModificacio;
	}
	
	public String getMidaTaula() {
		return midaTaula;
	}

	public void setMidaTaula(String midaTaula) {
		this.midaTaula = midaTaula;
	}

	//Creaci� del bean del crud que s'estigui realitzant
	private TbUsuaris usuari = new TbUsuaris();
	public TbUsuaris getUsuari() {
		return usuari;
	}

	public void setUsuari(TbUsuaris usuari) {
		this.usuari = usuari;
	}
	
	//Injecci� de depend�ncia del Service creat
	@Autowired
	private UsuariService service;
	
	/******************************************Accions del listener *********************************************/
	
//	public void selectionListener(ActionEvent event){
//
//	      UIExtendedDataTable dataTable = (UIExtendedDataTable)event.getComponent();
//
//	      Object originalKey = dataTable.getRowKey();
//
//	      selectionItems.clear();
//
//	      for (Object selectionKey: selection) {
//
//	         dataTable.setRowKey(selectionKey);
//
//	         if (dataTable.isRowAvailable()){
//
//	            selectionItems.add((TbUsuaris)dataTable.getRowData());
//
//	         }
//
//	      }
//
//	      dataTable.setRowKey(originalKey);
//
//	   }
	
	/************************************************Accions del CRUD ******************************************************
	/**
	 * modificarUsuari
	 */
	public void altaUsuari() {
		this.usuari.setIdUsuari(null);	
		service.altaUsuari(this.usuari);
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		FacesContext.getCurrentInstance().addMessage("formulariLlistat", 
				new FacesMessage(FacesMessage.SEVERITY_INFO, "S'ha donat d'alta l'usuari " + this.usuari.getNom(), null));
	}
	
	/**
	 * modificarUsuari
	 */
	public void modificarUsuari() {
		service.guardaUsuari(this.usuari);
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		FacesContext.getCurrentInstance().addMessage("formulariLlistat", 
				new FacesMessage(FacesMessage.SEVERITY_INFO, "S'ha modificat l'usuari", null));
	}
	
	/**
	 * eliminarUsuari
	 */
	public void eliminarUsuari() {
		TbUsuaris usuari = (TbUsuaris) model.getRowData();
		service.eliminaUsuari(usuari);
		FacesContext.getCurrentInstance().
			addMessage("formulariLlistat", new FacesMessage(FacesMessage.SEVERITY_INFO, 
					"S'ha eliminat l'usuari", null));
	}
	
	/**
	 * getUsuaris
	 * @return
	 */
	public DataModel getUsuaris() {
		model = new ListDataModel(service.getLlistaUsuaris(this.usuari));
		
		//C�lcul de la mida que ha de tindre la taula en funci� de les files mostrades
		int midaTaulaInt = 42; //mida m�nima de la taula
		if (model.getRowCount() >= MAX_PAGE) {
			midaTaulaInt = midaTaulaInt + MAX_PAGE * 22;
		} else {
			midaTaulaInt = midaTaulaInt + model.getRowCount() * 22;
		}
		midaTaula = midaTaulaInt + "px";
		return model;
	}
	
	public void onAction(ActionEvent actionEvent) {  
		int paginaActual = getPaginaActual(actionEvent, MAX_PAGE);
		
		//C�lcul de l'al�ada de la taula
		int midaTaulaInt = 42; //mida m�nima de la taula	
		
		int numeroRows = model.getRowCount() % (paginaActual * MAX_PAGE);
		midaTaulaInt = midaTaulaInt + numeroRows * 21;
		midaTaula = midaTaulaInt + "px";
		
	}

	
	private int getPaginaActual(ActionEvent actionEvent, int tamanyPagina) {
		
		int pagActual = 0;
		
		try {
//			if(actionEvent.getComponent() instanceof HtmlDatascroller ){  
//				  
//				HtmlDatascroller datascroller = (HtmlDatascroller) actionEvent.getComponent();  
//				DataScrollerEvent eve = (DataScrollerEvent) actionEvent;  
//			  
//				if(eve.getNewScrolVal().equals("first")){  
//					pagActual=0;  
//				}else if(eve.getNewScrolVal().equals("last")){  
//					pagActual=(eve.getPage()-1)*tamanyPagina;
//				}else if(eve.getNewScrolVal().equals("fastforward")){
//					System.out.println(eve.getPage());  
//		          	pagActual=(eve.getPage()-1)*tamanyPagina;
//				}else if(eve.getNewScrolVal().equals("next")){
//					pagActual=(eve.getPage()-1)*tamanyPagina;
//				}else if(eve.getNewScrolVal().equals("fastrewind")){
//					pagActual=(eve.getPage()*tamanyPagina)-tamanyPagina;
//				}else if(eve.getNewScrolVal().equals("previous")){
//					pagActual=(eve.getPage()*tamanyPagina)-tamanyPagina;
//				}else{
//					pagActual=(Integer.parseInt(eve.getNewScrolVal())*tamanyPagina)-tamanyPagina;
//				}
//				return pagActual;
//			}
			return 0;
		} catch (Exception e) {
			return 0;
		}
	}

	// ********************************* Accions de navegaci�*****************************************
	/**
	 * navigateModificarMaquina
	 */
	public void navigateModificarUsuari() {
		TbUsuaris usuari = (TbUsuaris) model.getRowData();
		this.visualitzarFormulariModificacio = true;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = false;
		this.usuari = usuari;
	}

	/**
	 * navigateEliminarMaquina
	 */
	public void navigateEliminarUsuari() {
		TbUsuaris usuari = (TbUsuaris) model.getRowData();
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
		this.usuari = usuari;
	}

	/**
	 * visualitzaAltaForm
	 */
	public void visualitzaAltaForm() {
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = true;
		this.visualitzarBotoAfegir = false;
	}
	
	/**
	 * cancelaModificacio
	 */
	public void cancelaModificacio() {
		this.visualitzarFormulariModificacio = false;
		this.visualitzarFormulariAlta = false;
		this.visualitzarBotoAfegir = true;
	}
}
