package cat.gencat.demo.canigo3.richfaces4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cat.gencat.demo.canigo3.richfaces4.bean.model.TbCluster;
import cat.gencat.demo.canigo3.richfaces4.dao.ClusterDAO;

//TODO 3 Canvi del nom del Servei
@Service("clusterService")
@Lazy
public class ClusterService {

	//TODO 4 Canviar el dao a injectar
	@Autowired
	private ClusterDAO dao;
	
	//TODO 5 Per a cadascun dels m�todes pasar com a par�metre 
	public void altaCluster(TbCluster cluster) {
		dao.save(cluster);
	}
	
	public void guardaCluster(TbCluster cluster) {
		dao.update(cluster);
	}
	
	public void eliminaCluster(TbCluster cluster) {
		dao.delete(cluster);
	}
	
	public List getLlistaCluster() {
		return dao.findAll();
	}

	public String getClusterName(Integer id) {
		TbCluster cluster = dao.get(id);
		return cluster.getNomCluster();
	}
}
