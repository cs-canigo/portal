package cat.gencat.demo.canigo3.richfaces4.dao.impl;

import java.util.HashMap;
import java.util.List;

import cat.gencat.ctti.canigo.arch.persistence.jpa.dao.impl.JPAGenericDaoImpl;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbNavegacio;
import cat.gencat.demo.canigo3.richfaces4.dao.AriadnaDAO;

public class AriadnaDAOImpl extends JPAGenericDaoImpl<TbNavegacio, Integer> implements AriadnaDAO{

	public List<TbNavegacio> cercaNavegacio(int idNavegacio) {
		List<TbNavegacio> cerca = null;
		try {
			
			HashMap<String, String> params1 = new HashMap<String, String>();
			params1.put("idNavegacio", Integer.toString(idNavegacio));
			cerca = findByNamedQueryAndNamedParams("findNavegacio", params1);
			return cerca;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
