package cat.gencat.demo.canigo3.richfaces4.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cat.gencat.demo.canigo3.richfaces4.bean.model.Option;
import cat.gencat.demo.canigo3.richfaces4.bean.model.TbMaquines;
import cat.gencat.demo.canigo3.richfaces4.service.MaquinaService;


@Controller("optionBean")
@Scope("singleton")
public class OptionBean implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3444950887991109517L;

	public String getOptionPasaPasSize() {
		return optionPasaPasSize;
	}

	public void setOptionPasaPasSize(String optionPasaPasSize) {
		this.optionPasaPasSize = optionPasaPasSize;
	}

	private String optionPasaPasSize = "4";

	public List<Option> getOpcionsMenuPasaPas() {
		
		List<Option> llistaOpcions = new ArrayList<Option>();
		
		Option op1 = new Option("PAS 1. Dades Personals", "OptionOK");
		Option op2 = new Option("PAS 2. Dades Generiques", "OptionSelected");
		Option op3 = new Option("PAS 3. Informaci� Addicional", "OptionPending");
		Option op4 = new Option("PAS 4. Tr�mits disponibles", "OptionPending OptionLast");
		
		llistaOpcions.add(op1);
		llistaOpcions.add(op2);
		llistaOpcions.add(op3);
		llistaOpcions.add(op4);
		
		return llistaOpcions;
	}

	
	
}
