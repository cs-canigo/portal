-------------------------------------------------------------------------------------------------------------
--
-- Arxiu de inserci� de dades d'exemple a la bbdd hsql
-- ---------------------------------------------------
--
--	Insercions:
--		
--		Taula "TB_USUARIS": Taula usuaris
--		Taula "TB_DEPARTAMENT": Taula Departament
--		Taula "TB_MAQUINES": Taula M�quines
--		Taula "TB_CLUSTER": Taula de Clusters
--
--
-------------------------------------------------------------------------------------------------------------
CREATE TABLE TB_CLUSTER (
	id_cluster INTEGER PRIMARY KEY,
	nom_cluster VARCHAR NOT NULL
);

CREATE TABLE TB_DEPARTAMENT (
	id_departament INTEGER IDENTITY PRIMARY KEY ,
	nom_departament VARCHAR NOT NULL
);

CREATE TABLE TB_USUARIS (
	id_usuari INTEGER IDENTITY PRIMARY KEY,
	nom VARCHAR NOT NULL,
	cognoms VARCHAR,
	telefon INTEGER,
	id_carrec INTEGER,
	email VARCHAR,
	nif VARCHAR,
	data_naixement DATE,
	id_departament INTEGER
);

CREATE TABLE TB_MAQUINES (
	id_maquina INTEGER IDENTITY PRIMARY KEY,
	nom_maquina VARCHAR NOT NULL,
	so VARCHAR,
	ip VARCHAR,
	id_cluster INTEGER,
	id_departament INTEGER,
	id_instrumentacio INTEGER,
	status INTEGER,
	disponible BOOLEAN
);

ALTER TABLE TB_USUARIS ADD CONSTRAINT departament_usuari_fk FOREIGN KEY (id_departament) REFERENCES TB_DEPARTAMENT (id_departament);


