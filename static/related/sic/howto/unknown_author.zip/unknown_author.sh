#!/bin/bash

echo 'unknown  <nouser@nomailgencat.cat>'

